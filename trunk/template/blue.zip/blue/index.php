<?php
header("location:../");
?>
